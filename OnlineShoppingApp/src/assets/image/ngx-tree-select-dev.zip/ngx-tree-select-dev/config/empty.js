module.exports = {
  NgProbeToken: {},
  HmrState: () => {},
  _createConditionalRootRenderer: (rootRenderer, extraTokens, coreTokens) => {
    return rootRenderer;
  },
  __platform_browser_private__: {}
};
