export class ExpandMode {
  public static None = 'None';
  public static Selection = 'Selection';
  public static All = 'All';
}
