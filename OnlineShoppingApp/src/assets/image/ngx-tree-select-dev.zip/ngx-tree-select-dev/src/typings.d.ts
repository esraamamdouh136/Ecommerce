declare namespace jest {
  interface Matchers {
    resolves: Matchers;
    rejects: Matchers;
  }
}
