import { Component } from '@angular/core';
import { HierarchicalCountries } from '../../datas/hierarchical-data';
import { FlatCountries } from '../../datas/flat-data';

@Component({
  selector: 'demo-app',
  templateUrl: './app.component.html'
})
export class AppComponent {

}
