export const FirstnameList = [
  'Jacques',
  'Jad',
  'Jana',
  'Jasmine',
  'Jeremie',
  'Jeremy',
  'Joachim',
  'Johan',
  'Johanna',
  'Jonathan',
  'Jordan',
  'Joseph',
  'Jules',
  'Justin'
];
